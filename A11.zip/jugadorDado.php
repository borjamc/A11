<?php

class jugadorDado
{
private $minNumDado=0;
private $maxNumDado=0;
public $tirarDado=0;

public function getminNumDado(){
  return $this->minNumDado;
}

public function getmaxNumDado(){
  return $this->maxNumDado;
}

public function setminNumDado($minNumDado){
  if ($minNumDado<0) {
    $this->minNumDado=0;
  }else{
  $this->minNumDado=$minNumDado;
  }
}

public function setmaxNumDado($maxNumDado){
  if ($maxNumDado>12) {
    $this->maxNumDado=12;
  }else{
  $this->maxNumDado=$maxNumDado;
  }
}

//Random
public function randompos(){
   $this->tirarDado = rand($this->minNumDado,$this->maxNumDado);
   return $this->tirarDado;
  }

}
 ?>
